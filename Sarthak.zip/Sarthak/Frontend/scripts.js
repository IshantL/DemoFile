const app = document.getElementById('root');

const title = document.createElement('h1');
title.innerHTML = "PDQ.com";   

const container = document.createElement('div');
container.setAttribute('class', 'container');

app.appendChild(title);
app.appendChild(container);

var request = new XMLHttpRequest();
request.open('GET', 'http://localhost:8079/getEmp', true);
//request.open('GET', 'https://pdqweb.azurewebsites.net/api/brain', true);
/* var data={
  "name": "Matt",
  "currentBeer": "Guinness",
  "currentThought": "I wonder why this works?",
  "daydream": "https://media.giphy.com/media/5nj4KLBy2mhkH1pUWT/giphy.gif"
} */
request.onload = function () {

  // Begin accessing JSON data here
  var data = JSON.parse(this.response);
  if (request.status >= 200 && request.status < 400) {
     
      const card = document.createElement('div');
      card.setAttribute('class', 'card');

      const h1 = document.createElement('h1');
      h1.textContent = data.name;

      const p = document.createElement('p');
      p.textContent = data.currentBeer;

      const p2 = document.createElement('p');
      p2.textContent = data.currentThought;

      const pic = document.createElement("IMG");
      pic.src = data.daydream;

      container.appendChild(card);
      card.appendChild(h1);
      card.appendChild(p);
      card.appendChild(p2);
      card.appendChild(pic);


  } else {
    const errorMessage = document.createElement('marquee');
    errorMessage.textContent = `Gah, it's not working!`;
    app.appendChild(errorMessage);
  }
}

request.send();
